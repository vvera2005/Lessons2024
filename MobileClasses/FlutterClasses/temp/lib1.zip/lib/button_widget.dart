import 'package:flutter/material.dart';

class ButtonWidget extends StatelessWidget {
  const ButtonWidget(this._globalKey, {super.key});

  final GlobalKey<FormState> _globalKey;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        if (_globalKey.currentState?.validate() == true) {
          ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
              content: Text('Logged in'), backgroundColor: Colors.red));
        }
      },
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: const BoxDecoration(color: Colors.green),
        child: const Text('Login',
            textAlign: TextAlign.center,
            style: TextStyle(
              color: Colors.white,
              fontSize: 20,
            )),
      ),
    );
  }
}
