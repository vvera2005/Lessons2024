import 'dart:io';

import 'package:first/button_widget.dart';
import 'package:first/pages/signup.dart';
import 'package:first/text_field_widget.dart';
import 'package:flutter/material.dart';

class Signin extends StatefulWidget {
  const Signin({super.key});

  @override
  State<Signin> createState() => _SigninState();
}

class _SigninState extends State<Signin> {
  final GlobalKey<FormState> _globalKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Sign in"),
        centerTitle: true,
        backgroundColor: Colors.white,
      ),
      body: Form(
        key: _globalKey,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 8),
          child: Center(
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: <Widget>[
                  TextFieldWidget(
                    hintText: 'Username',
                    validator: (String? value) {
                      if (value?.isEmpty == true) {
                        return "invalid username";
                      }
                      return null;
                    },
                  ),
                  const SizedBox(height: 16),
                  TextFieldWidget(
                    validator: (String? value) {
                      if (value?.isEmpty == true) {
                        return "invalid password";
                      }
                      return null;
                    },
                    hintText: 'Password',
                    obscureText: true,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      Padding(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 40, vertical: 32),
                        child: TextButton(
                            onPressed: () {},
                            child: const Text("Forgot your passward?",
                                style: TextStyle(
                                    color:
                                        Color.fromARGB(255, 116, 113, 113)))),
                      ),
                    ],
                  ),
                  ButtonWidget(_globalKey),
                  const SizedBox(height: 32),
                  const Text(
                    'or',
                    textAlign: TextAlign.center,
                    style: TextStyle(color: Colors.grey, fontSize: 20),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(20.0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: <Widget>[
                        IconButton(onPressed: () {}, icon: Icon(Icons.abc)),
                        IconButton(onPressed: () {}, icon: Icon(Icons.abc)),
                        IconButton(onPressed: () {}, icon: Icon(Icons.abc)),
                      ],
                    ),
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      const Text('Dont have an accaunt? '),
                      TextButton(
                          onPressed: () {
                            Navigator.of(context).pushNamed('/sign-up');
                          },
                          child: const Text('Sign up',
                              style: TextStyle(
                                  color: Color.fromARGB(255, 211, 111, 144))))
                    ],
                  )
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
