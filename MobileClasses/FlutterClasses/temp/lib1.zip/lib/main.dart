
import 'package:first/routes/routes.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(MaterialApp(
    routes: Routes.routes,
  ));
}
